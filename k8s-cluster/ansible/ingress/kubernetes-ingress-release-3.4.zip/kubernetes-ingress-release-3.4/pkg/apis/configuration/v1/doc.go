// +k8s:deepcopy-gen=package
// +groupName=k8s.nginx.org

// Package v1 is the v1 version of the API.
package v1
