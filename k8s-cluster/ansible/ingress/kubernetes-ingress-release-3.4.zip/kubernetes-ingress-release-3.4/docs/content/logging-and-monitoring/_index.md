---
title: Logging And Monitoring
description:
weight: 1500
menu:
  docs:
    parent: NGINX Ingress Controller
---
