---
title: NGINX App Protect WAF
description: Learn how to use NGINX Ingress Controller for Kubernetes with NGINX App Protect.
weight: 100
aliases: ["/nginx-ingress-controller/app-protect/"]
menu:
  docs:
    parent: NGINX Ingress Controller
---
