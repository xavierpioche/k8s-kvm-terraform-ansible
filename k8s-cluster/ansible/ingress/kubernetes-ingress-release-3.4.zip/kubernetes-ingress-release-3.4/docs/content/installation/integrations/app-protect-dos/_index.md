---
title: NGINX App Protect DoS
description: Learn how to use NGINX Ingress Controller for Kubernetes with NGINX App Protect DoS.
weight: 200
menu:
  docs:
    parent: Integrations
---
