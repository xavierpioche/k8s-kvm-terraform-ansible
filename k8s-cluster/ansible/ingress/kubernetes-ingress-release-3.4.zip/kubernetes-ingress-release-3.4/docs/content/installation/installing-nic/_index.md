---
title: Installing NGINX Ingress Controller
description:
weight: 100
---
