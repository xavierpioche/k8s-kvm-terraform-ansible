---
title: Installation
description:
weight: 400
menu:
  docs:
    parent: NGINX Ingress Controller
---
