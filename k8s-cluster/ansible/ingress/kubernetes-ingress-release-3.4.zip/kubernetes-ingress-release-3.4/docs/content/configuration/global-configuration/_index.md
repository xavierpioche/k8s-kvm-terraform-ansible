---
title: Global Configuration
description:
weight: 1400
menu:
  docs:
    parent: NGINX Ingress Controller
---
